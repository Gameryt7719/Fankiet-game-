import { pgTable, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const roomsTable = pgTable("rooms", {
  code: text("code").primaryKey(),
  category: text("category").notNull().default("general"),
  totalRounds: integer("total_rounds").notNull().default(3),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const gameScoresTable = pgTable("game_scores", {
  id: text("id").primaryKey(),
  roomCode: text("room_code").notNull(),
  playerName: text("player_name").notNull(),
  playerId: text("player_id").notNull(),
  score: integer("score").notNull().default(0),
  roundsWon: integer("rounds_won").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRoomSchema = createInsertSchema(roomsTable);
export const insertGameScoreSchema = createInsertSchema(gameScoresTable);

export type Room = typeof roomsTable.$inferSelect;
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type GameScore = typeof gameScoresTable.$inferSelect;
export type InsertGameScore = z.infer<typeof insertGameScoreSchema>;
