import React, { createContext, useContext, useEffect, useState, ReactNode, useRef } from "react";
import { io, Socket } from "socket.io-client";
import type { Room } from "@workspace/api-client-react";

interface RoleAssignedEvent {
  role: 'imposter' | 'player';
  topic: string | null;
}

interface SocketContextType {
  socket: Socket | null;
  isConnected: boolean;
  roomState: Room | null;
  roleData: RoleAssignedEvent | null;
  error: string | null;
  connectSocket: (roomCode: string, playerId: string) => void;
  disconnectSocket: () => void;
}

const SocketContext = createContext<SocketContextType>({
  socket: null,
  isConnected: false,
  roomState: null,
  roleData: null,
  error: null,
  connectSocket: () => {},
  disconnectSocket: () => {},
});

export const useGameSocket = () => useContext(SocketContext);

export const SocketProvider = ({ children }: { children: ReactNode }) => {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [roomState, setRoomState] = useState<Room | null>(null);
  const [roleData, setRoleData] = useState<RoleAssignedEvent | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const socketRef = useRef<Socket | null>(null);

  const connectSocket = (roomCode: string, playerId: string) => {
    if (socketRef.current) {
      socketRef.current.disconnect();
    }

    const newSocket = io(window.location.origin, {
      path: "/socket.io",
      auth: { roomCode, playerId },
    });

    newSocket.on("connect", () => {
      setIsConnected(true);
      setError(null);
    });

    newSocket.on("disconnect", () => {
      setIsConnected(false);
    });

    newSocket.on("room_state", (state: Room) => {
      setRoomState(state);
    });

    newSocket.on("role_assigned", (data: RoleAssignedEvent) => {
      setRoleData(data);
    });

    newSocket.on("error", (err: { message: string }) => {
      setError(err.message);
    });

    socketRef.current = newSocket;
    setSocket(newSocket);
  };

  const disconnectSocket = () => {
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    setSocket(null);
    setIsConnected(false);
    setRoomState(null);
    setRoleData(null);
    setError(null);
  };

  useEffect(() => {
    return () => {
      disconnectSocket();
    };
  }, []);

  return (
    <SocketContext.Provider
      value={{
        socket,
        isConnected,
        roomState,
        roleData,
        error,
        connectSocket,
        disconnectSocket,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};
