import { Shield, Skull, Eye, EyeOff } from "lucide-react";
import { useState } from "react";

export default function Demo() {
  const [showTopic, setShowTopic] = useState(false);

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-10 p-8">
      <div className="text-center">
        <h1 className="text-3xl font-black text-primary text-glow tracking-widest mb-1">FAKEIT</h1>
        <p className="text-muted-foreground text-sm uppercase tracking-widest">Player Role Cards</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-8 items-center justify-center w-full max-w-2xl">

        {/* IMPOSTER CARD */}
        <div className="flex flex-col items-center gap-3 w-full max-w-xs">
          <p className="text-xs text-muted-foreground uppercase tracking-widest font-semibold">1 player sees this</p>
          <div className="w-full rounded-3xl p-8 text-center flex flex-col items-center gap-4 border-2 bg-destructive/10 border-destructive/50"
            style={{ boxShadow: "0 0 24px hsl(var(--destructive) / 0.3)" }}>
            <Skull className="h-16 w-16 text-destructive" />
            <div>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mb-1">You are the</p>
              <p className="text-4xl font-black tracking-wide text-destructive"
                style={{ textShadow: "0 0 20px hsl(var(--destructive) / 0.8)" }}>
                IMPOSTER
              </p>
            </div>
            <div className="mt-2 w-full">
              <p className="text-sm text-muted-foreground mb-1">Secret Topic</p>
              <div className="bg-muted/50 rounded-xl px-6 py-3 text-2xl font-black tracking-widest">???</div>
              <p className="text-xs text-muted-foreground mt-2">Blend in. Don't get caught.</p>
            </div>
          </div>
          <p className="text-xs text-center text-muted-foreground max-w-[220px]">
            The imposter has <strong className="text-destructive">no idea</strong> what the topic is — they must fake it
          </p>
        </div>

        {/* DIVIDER */}
        <div className="text-muted-foreground font-bold text-lg hidden sm:block">VS</div>
        <div className="text-muted-foreground font-bold text-lg sm:hidden">— VS —</div>

        {/* PLAYER CARD */}
        <div className="flex flex-col items-center gap-3 w-full max-w-xs">
          <p className="text-xs text-muted-foreground uppercase tracking-widest font-semibold">All others see this</p>
          <div className="w-full rounded-3xl p-8 text-center flex flex-col items-center gap-4 border-2 bg-secondary/10 border-secondary/40"
            style={{ boxShadow: "0 0 24px hsl(var(--secondary) / 0.3)" }}>
            <Shield className="h-16 w-16 text-secondary" />
            <div>
              <p className="text-xs uppercase tracking-widest text-muted-foreground mb-1">You are the</p>
              <p className="text-4xl font-black tracking-wide text-secondary"
                style={{ textShadow: "0 0 20px hsl(var(--secondary) / 0.8)" }}>
                PLAYER
              </p>
            </div>
            <div className="mt-2 w-full">
              <p className="text-sm text-muted-foreground mb-1">Secret Topic</p>
              <div className={`rounded-xl px-6 py-3 font-black text-xl tracking-wide flex items-center justify-center gap-2 ${
                showTopic ? "bg-secondary/20 text-secondary" : "bg-muted/50 text-muted-foreground"
              }`}>
                {showTopic ? "Pizza" : "••••••••"}
                <button onClick={() => setShowTopic(v => !v)} className="ml-2">
                  {showTopic ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Shield your screen from the imposter!</p>
            </div>
          </div>
          <p className="text-xs text-center text-muted-foreground max-w-[220px]">
            Players <strong className="text-secondary">know the topic</strong> — give clues without making it too obvious
          </p>
        </div>
      </div>

      <p className="text-xs text-muted-foreground text-center max-w-sm">
        Tap the <strong>👁</strong> button to reveal/hide the topic — handy when passing your phone around
      </p>
    </div>
  );
}
