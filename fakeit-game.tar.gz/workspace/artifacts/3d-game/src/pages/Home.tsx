import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useCreateRoom, useJoinRoom, useListTopicCategories } from "@workspace/api-client-react";
import { Users, Zap, Lock, Globe, ChevronRight, Gamepad2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

type Mode = "home" | "create" | "join";

interface Category {
  id: string;
  name: string;
  description: string;
  topicCount: number;
  isAdult: boolean;
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<Mode>("home");

  // Create Room form
  const [hostName, setHostName] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("general");
  const [totalRounds, setTotalRounds] = useState(3);

  // Join Room form
  const [joinCode, setJoinCode] = useState("");
  const [joinName, setJoinName] = useState("");

  const { data: categories } = useListTopicCategories();

  const createRoom = useCreateRoom({
    mutation: {
      onSuccess: (data: { code: string; hostId?: string }) => {
        const playerId = (data as { hostId?: string }).hostId ?? "";
        sessionStorage.setItem("playerId", playerId);
        sessionStorage.setItem("roomCode", data.code);
        setLocation(`/room/${data.code}`);
      },
    },
  });

  const joinRoom = useJoinRoom({
    mutation: {
      onSuccess: (data: { room: { code: string }; playerId: string }) => {
        sessionStorage.setItem("playerId", data.playerId);
        sessionStorage.setItem("roomCode", data.room.code);
        setLocation(`/room/${data.room.code}`);
      },
      onError: (err: { response?: { data?: { error?: string } } }) => {
        alert(err?.response?.data?.error ?? "Could not join room. Check the code and try again.");
      },
    },
  });

  const handleCreate = () => {
    if (!hostName.trim()) return;
    createRoom.mutate({
      data: {
        hostName: hostName.trim(),
        category: selectedCategory,
        totalRounds,
        maxPlayers: 8,
        clueTimerSeconds: 60,
        discussionTimerSeconds: 90,
      },
    });
  };

  const handleJoin = () => {
    if (!joinCode.trim() || !joinName.trim()) return;
    joinRoom.mutate({
      code: joinCode.trim().toUpperCase(),
      data: { playerName: joinName.trim() },
    });
  };

  return (
    <div className="min-h-dvh flex flex-col items-center justify-center px-4 py-8">
      <AnimatePresence mode="wait">
        {mode === "home" && (
          <motion.div
            key="home"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col items-center gap-8 w-full max-w-sm"
          >
            {/* Logo */}
            <div className="flex flex-col items-center gap-2">
              <motion.div
                animate={{ scale: [1, 1.04, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                className="text-8xl font-black tracking-tighter text-glow"
                style={{ color: "hsl(var(--primary))", fontFamily: "'Outfit', sans-serif" }}
                data-testid="logo-title"
              >
                FAKEIT
              </motion.div>
              <p className="text-muted-foreground text-sm tracking-widest uppercase font-medium">
                The Imposter Party Game
              </p>
            </div>

            {/* Tagline */}
            <div className="text-center space-y-1">
              <p className="text-foreground/70 text-sm">
                One player knows nothing. Everyone else knows everything.
              </p>
              <p className="text-foreground/50 text-xs">Can you spot the imposter?</p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col gap-3 w-full">
              <Button
                className="h-14 text-lg font-bold tracking-wide box-glow"
                onClick={() => setMode("create")}
                data-testid="button-create-room"
              >
                <Zap className="mr-2 h-5 w-5" />
                Create Room
              </Button>
              <Button
                variant="outline"
                className="h-14 text-lg font-bold tracking-wide border-secondary/30 text-secondary hover:bg-secondary/10"
                onClick={() => setMode("join")}
                data-testid="button-join-room"
              >
                <Users className="mr-2 h-5 w-5" />
                Join Room
              </Button>
            </div>

            {/* Stats */}
            <div className="flex gap-6 text-center">
              <div>
                <div className="text-2xl font-black text-primary">109M+</div>
                <div className="text-xs text-muted-foreground">Views</div>
              </div>
              <div className="w-px bg-border" />
              <div>
                <div className="text-2xl font-black text-secondary">3-8</div>
                <div className="text-xs text-muted-foreground">Players</div>
              </div>
              <div className="w-px bg-border" />
              <div>
                <div className="text-2xl font-black text-accent">4</div>
                <div className="text-xs text-muted-foreground">Categories</div>
              </div>
            </div>
          </motion.div>
        )}

        {mode === "create" && (
          <motion.div
            key="create"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col gap-6 w-full max-w-sm"
          >
            <div className="flex items-center gap-3">
              <button
                onClick={() => setMode("home")}
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-back-home"
              >
                ← Back
              </button>
              <h2 className="text-2xl font-black tracking-wide text-primary text-glow">
                Create Room
              </h2>
            </div>

            <div className="card-glass rounded-2xl p-5 flex flex-col gap-5">
              <div className="space-y-2">
                <Label htmlFor="host-name" className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Your Name
                </Label>
                <Input
                  id="host-name"
                  placeholder="Enter your name"
                  value={hostName}
                  onChange={(e) => setHostName(e.target.value)}
                  maxLength={20}
                  className="h-12 text-base bg-muted/40 border-border/60"
                  data-testid="input-host-name"
                  onKeyDown={(e) => e.key === "Enter" && handleCreate()}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Category Pack
                </Label>
                <div className="grid grid-cols-2 gap-2">
                  {(categories ?? defaultCategories).map((cat: Category) => (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCategory(cat.id)}
                      data-testid={`button-category-${cat.id}`}
                      className={`p-3 rounded-xl text-left transition-all border ${
                        selectedCategory === cat.id
                          ? "border-primary bg-primary/15 text-primary"
                          : "border-border/40 bg-muted/30 text-muted-foreground hover:border-border hover:text-foreground"
                      }`}
                    >
                      <div className="flex items-center gap-1 mb-0.5">
                        {cat.isAdult ? (
                          <Lock className="h-3 w-3 shrink-0" />
                        ) : (
                          <Globe className="h-3 w-3 shrink-0" />
                        )}
                        <span className="text-xs font-bold uppercase tracking-wide">{cat.name}</span>
                      </div>
                      <div className="text-xs opacity-70">{cat.topicCount} topics</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Rounds: {totalRounds}
                </Label>
                <input
                  type="range"
                  min={1}
                  max={10}
                  value={totalRounds}
                  onChange={(e) => setTotalRounds(Number(e.target.value))}
                  className="w-full accent-primary"
                  data-testid="input-rounds"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1 round</span>
                  <span>10 rounds</span>
                </div>
              </div>

              <Button
                className="h-12 text-base font-bold box-glow"
                onClick={handleCreate}
                disabled={!hostName.trim() || createRoom.isPending}
                data-testid="button-submit-create"
              >
                {createRoom.isPending ? (
                  "Creating..."
                ) : (
                  <>
                    Create Room <ChevronRight className="ml-1 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </motion.div>
        )}

        {mode === "join" && (
          <motion.div
            key="join"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            transition={{ duration: 0.3 }}
            className="flex flex-col gap-6 w-full max-w-sm"
          >
            <div className="flex items-center gap-3">
              <button
                onClick={() => setMode("home")}
                className="text-muted-foreground hover:text-foreground transition-colors"
                data-testid="button-back-home-join"
              >
                ← Back
              </button>
              <h2 className="text-2xl font-black tracking-wide text-secondary text-glow-secondary">
                Join Room
              </h2>
            </div>

            <div className="card-glass rounded-2xl p-5 flex flex-col gap-5">
              <div className="space-y-2">
                <Label htmlFor="join-code" className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Room Code
                </Label>
                <Input
                  id="join-code"
                  placeholder="XXXXXX"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  maxLength={6}
                  className="h-14 text-2xl font-black text-center tracking-[0.3em] bg-muted/40 border-border/60"
                  data-testid="input-join-code"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="join-name" className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                  Your Name
                </Label>
                <Input
                  id="join-name"
                  placeholder="Enter your name"
                  value={joinName}
                  onChange={(e) => setJoinName(e.target.value)}
                  maxLength={20}
                  className="h-12 text-base bg-muted/40 border-border/60"
                  data-testid="input-join-name"
                  onKeyDown={(e) => e.key === "Enter" && handleJoin()}
                />
              </div>

              <Button
                className="h-12 text-base font-bold border-secondary/40 text-secondary hover:bg-secondary/15 box-glow-secondary"
                variant="outline"
                onClick={handleJoin}
                disabled={!joinCode.trim() || !joinName.trim() || joinRoom.isPending}
                data-testid="button-submit-join"
              >
                {joinRoom.isPending ? (
                  "Joining..."
                ) : (
                  <>
                    <Gamepad2 className="mr-2 h-4 w-4" />
                    Join Game
                  </>
                )}
              </Button>
            </div>

            <p className="text-center text-xs text-muted-foreground">
              Ask the host for the 6-character room code
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const defaultCategories: Category[] = [
  { id: "general", name: "General", description: "Everyday things", topicCount: 88, isAdult: false },
  { id: "family", name: "Family Fun", description: "All ages", topicCount: 53, isAdult: false },
  { id: "pop-culture", name: "Pop Culture", description: "Movies & more", topicCount: 41, isAdult: false },
  { id: "adult", name: "Adults Only", description: "Mature content", topicCount: 44, isAdult: true },
];
