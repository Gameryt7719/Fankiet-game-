import { useEffect, useState, useRef } from "react";
import { useParams, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useGameSocket } from "@/lib/socket";
import { Users, Copy, Check, Crown, Wifi, WifiOff, Trophy, Clock, Eye, EyeOff, ChevronRight, RotateCcw, Skull, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface Player {
  id: string;
  name: string;
  isHost: boolean;
  score: number;
  isConnected: boolean;
}

interface RoundResult {
  imposterId: string;
  imposterName: string;
  topic: string;
  wasImposterCaught: boolean;
  votes: Record<string, string>;
  clues: Record<string, string>;
  scoreDelta: Record<string, number>;
}

interface RoomState {
  code: string;
  players: Player[];
  status: string;
  currentRound: number;
  totalRounds: number;
  category: string;
  maxPlayers: number;
  clueTimerSeconds: number;
  discussionTimerSeconds: number;
  timerEndAt: number | null;
  clues: Record<string, string>;
  votes: Record<string, string>;
  lastRoundResult: RoundResult | null;
}

function useTimer(endAt: number | null) {
  const [remaining, setRemaining] = useState<number>(0);
  useEffect(() => {
    if (!endAt) { setRemaining(0); return; }
    const update = () => {
      const diff = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
      setRemaining(diff);
    };
    update();
    const id = setInterval(update, 500);
    return () => clearInterval(id);
  }, [endAt]);
  return remaining;
}

export default function RoomPage() {
  const { code } = useParams<{ code: string }>();
  const [, setLocation] = useLocation();
  const { socket, isConnected, roomState: rawRoomState, roleData, connectSocket } = useGameSocket();

  const roomState = rawRoomState as RoomState | null;

  const [playerId] = useState(() => sessionStorage.getItem("playerId") ?? "");
  const [copied, setCopied] = useState(false);
  const [clueInput, setClueInput] = useState("");
  const [hasSubmittedClue, setHasSubmittedClue] = useState(false);
  const [hasVoted, setHasVoted] = useState(false);
  const [showTopic, setShowTopic] = useState(false);
  const prevStatusRef = useRef<string>("");

  // Reset per-round state when round changes
  useEffect(() => {
    if (!roomState) return;
    const prevStatus = prevStatusRef.current;
    if (prevStatus !== roomState.status) {
      if (roomState.status === "clue_phase") {
        setClueInput("");
        setHasSubmittedClue(false);
        setShowTopic(false);
      }
      if (roomState.status === "voting") {
        setHasVoted(false);
      }
      prevStatusRef.current = roomState.status;
    }
  }, [roomState]);

  // Connect socket when component mounts
  useEffect(() => {
    if (!playerId || !code) {
      setLocation("/");
      return;
    }
    connectSocket(code, playerId);
  }, [code, playerId]); // eslint-disable-line react-hooks/exhaustive-deps

  const me = roomState?.players.find((p) => p.id === playerId);
  const isHost = me?.isHost ?? false;
  const timerRemaining = useTimer(roomState?.timerEndAt ?? null);

  const copyCode = async () => {
    await navigator.clipboard.writeText(roomState?.code ?? code ?? "").catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const emitStartGame = () => socket?.emit("start_game");
  const emitNextRound = () => socket?.emit("next_round");
  const emitEndGame = () => socket?.emit("end_game");
  const emitResetLobby = () => socket?.emit("reset_to_lobby");

  const submitClue = () => {
    if (!clueInput.trim() || hasSubmittedClue) return;
    socket?.emit("submit_clue", { clue: clueInput.trim() });
    setHasSubmittedClue(true);
  };

  const submitVote = (targetId: string) => {
    if (hasVoted || targetId === playerId) return;
    socket?.emit("submit_vote", { targetId });
    setHasVoted(true);
  };

  if (!roomState) {
    return (
      <div className="min-h-dvh flex flex-col items-center justify-center gap-4">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
          className="w-10 h-10 rounded-full border-2 border-primary border-t-transparent"
        />
        <p className="text-muted-foreground text-sm">
          {isConnected ? "Loading room..." : "Connecting..."}
        </p>
        {!isConnected && (
          <Button variant="ghost" size="sm" onClick={() => setLocation("/")}>
            Back to Home
          </Button>
        )}
      </div>
    );
  }

  const status = roomState.status;

  return (
    <div className="min-h-dvh flex flex-col px-4 py-6 max-w-lg mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <button onClick={() => setLocation("/")} className="text-muted-foreground text-sm hover:text-foreground">
          ← Home
        </button>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground uppercase tracking-widest font-semibold">
            {status === "lobby" ? "Lobby" :
             status === "role_reveal" ? "Role Reveal" :
             status === "clue_phase" ? `Round ${roomState.currentRound}` :
             status === "discussion" ? "Discussion" :
             status === "voting" ? "Voting" :
             status === "reveal" ? "Reveal" : "Scores"}
          </span>
          {status !== "lobby" && status !== "scores" && (
            <span className="text-xs text-muted-foreground">
              {roomState.currentRound}/{roomState.totalRounds}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5 text-xs">
          {isConnected ? (
            <><Wifi className="h-3 w-3 text-secondary" /><span className="text-secondary">Live</span></>
          ) : (
            <><WifiOff className="h-3 w-3 text-destructive" /><span className="text-destructive">Offline</span></>
          )}
        </div>
      </div>

      <AnimatePresence mode="wait">

        {/* === LOBBY === */}
        {status === "lobby" && (
          <motion.div key="lobby" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col gap-5 flex-1">

            {/* Room Code */}
            <div className="card-glass rounded-2xl p-5 text-center">
              <p className="text-xs text-muted-foreground uppercase tracking-widest mb-2 font-semibold">Room Code</p>
              <div className="flex items-center justify-center gap-3">
                <span className="text-5xl font-black tracking-[0.15em] text-primary text-glow"
                  data-testid="text-room-code">
                  {roomState.code}
                </span>
                <button onClick={copyCode} className="p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  data-testid="button-copy-code">
                  {copied ? <Check className="h-4 w-4 text-secondary" /> : <Copy className="h-4 w-4 text-muted-foreground" />}
                </button>
              </div>
              <p className="text-xs text-muted-foreground mt-2">Share this code with friends</p>
            </div>

            {/* Category */}
            <div className="card-glass rounded-xl px-4 py-3 flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Category</span>
              <span className="text-sm font-bold capitalize text-accent">{roomState.category.replace("-", " ")}</span>
            </div>

            {/* Player List */}
            <div className="card-glass rounded-2xl p-4 flex flex-col gap-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase tracking-widest text-muted-foreground font-semibold">
                  Players
                </span>
                <span className="text-xs text-muted-foreground">{roomState.players.length}/{roomState.maxPlayers}</span>
              </div>
              {roomState.players.map((player) => (
                <div key={player.id}
                  className={`flex items-center gap-3 p-2 rounded-lg ${player.id === playerId ? "bg-primary/10" : ""}`}
                  data-testid={`player-row-${player.id}`}>
                  <div className={`w-2 h-2 rounded-full ${player.isConnected ? "bg-secondary" : "bg-muted-foreground"}`} />
                  <span className={`flex-1 font-medium ${player.id === playerId ? "text-primary" : "text-foreground"}`}>
                    {player.name} {player.id === playerId && <span className="text-xs text-muted-foreground">(you)</span>}
                  </span>
                  {player.isHost && <Crown className="h-3.5 w-3.5 text-yellow-400" />}
                </div>
              ))}
              {roomState.players.length < 3 && (
                <p className="text-xs text-muted-foreground text-center mt-2">
                  Need {3 - roomState.players.length} more player{3 - roomState.players.length !== 1 ? "s" : ""} to start
                </p>
              )}
            </div>

            {isHost && (
              <Button
                className="h-14 text-lg font-bold box-glow"
                disabled={roomState.players.filter((p) => p.isConnected).length < 3}
                onClick={emitStartGame}
                data-testid="button-start-game"
              >
                <Zap className="mr-2 h-5 w-5" />
                Start Game
              </Button>
            )}
            {!isHost && (
              <div className="text-center text-sm text-muted-foreground py-3">
                Waiting for the host to start the game...
              </div>
            )}
          </motion.div>
        )}

        {/* === ROLE REVEAL === */}
        {status === "role_reveal" && (
          <motion.div key="role_reveal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center gap-6 flex-1">

            <p className="text-sm text-muted-foreground uppercase tracking-widest font-semibold">Round {roomState.currentRound} of {roomState.totalRounds}</p>

            {roleData ? (
              <motion.div
                initial={{ rotateY: 90, opacity: 0 }}
                animate={{ rotateY: 0, opacity: 1 }}
                transition={{ duration: 0.5, delay: 0.2 }}
                className={`w-full max-w-xs rounded-3xl p-8 text-center flex flex-col items-center gap-4 border-2 ${
                  roleData.role === "imposter"
                    ? "bg-destructive/10 border-destructive/50 box-glow-destructive"
                    : "bg-secondary/10 border-secondary/40 box-glow-secondary"
                }`}
                data-testid="card-role-reveal"
              >
                <div className="text-6xl">
                  {roleData.role === "imposter"
                    ? <Skull className="h-16 w-16 text-destructive" />
                    : <Shield className="h-16 w-16 text-secondary" />
                  }
                </div>
                <div>
                  <p className="text-xs uppercase tracking-widest text-muted-foreground mb-1">You are the</p>
                  <p className={`text-4xl font-black tracking-wide ${
                    roleData.role === "imposter" ? "text-destructive text-glow" : "text-secondary text-glow-secondary"
                  }`}>
                    {roleData.role === "imposter" ? "IMPOSTER" : "PLAYER"}
                  </p>
                </div>
                {roleData.role === "imposter" ? (
                  <div className="mt-2">
                    <p className="text-sm text-muted-foreground mb-1">Secret Topic</p>
                    <div className="bg-muted/50 rounded-xl px-6 py-3 text-2xl font-black tracking-widest">???</div>
                    <p className="text-xs text-muted-foreground mt-2">Blend in. Don't get caught.</p>
                  </div>
                ) : (
                  <div className="mt-2">
                    <p className="text-sm text-muted-foreground mb-1">Secret Topic</p>
                    <div className={`rounded-xl px-6 py-3 font-black text-xl tracking-wide flex items-center gap-2 ${
                      showTopic ? "bg-secondary/20 text-secondary" : "bg-muted/50 text-muted-foreground"
                    }`}>
                      {showTopic ? roleData.topic : "••••••••"}
                      <button onClick={() => setShowTopic((v) => !v)} className="ml-2">
                        {showTopic ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">Shield your screen from the imposter!</p>
                  </div>
                )}
              </motion.div>
            ) : (
              <div className="flex flex-col items-center gap-3">
                <motion.div animate={{ rotate: 360 }} transition={{ duration: 1.5, repeat: Infinity, ease: "linear" }}
                  className="w-10 h-10 rounded-full border-2 border-primary border-t-transparent" />
                <p className="text-muted-foreground">Assigning roles...</p>
              </div>
            )}

            <p className="text-xs text-muted-foreground text-center max-w-xs">
              Clue phase starts in a moment. Remember your role!
            </p>
          </motion.div>
        )}

        {/* === CLUE PHASE === */}
        {status === "clue_phase" && (
          <motion.div key="clue_phase" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col gap-5 flex-1">

            <TimerBar remaining={timerRemaining} total={roomState.clueTimerSeconds} color="primary" />

            <div className="card-glass rounded-xl px-4 py-3 text-center">
              <p className="text-xs text-muted-foreground uppercase tracking-widest mb-1">Your Role</p>
              {roleData ? (
                <div className="flex items-center justify-center gap-2">
                  {roleData.role === "imposter"
                    ? <Skull className="h-4 w-4 text-destructive" />
                    : <Shield className="h-4 w-4 text-secondary" />}
                  <span className={`font-bold ${roleData.role === "imposter" ? "text-destructive" : "text-secondary"}`}>
                    {roleData.role === "imposter" ? "IMPOSTER — Topic: ???" : `PLAYER — Topic: ${roleData.topic}`}
                  </span>
                </div>
              ) : <span className="text-muted-foreground text-sm">Loading...</span>}
            </div>

            {/* Submit clue */}
            {!hasSubmittedClue ? (
              <div className="card-glass rounded-2xl p-4 flex flex-col gap-3">
                <p className="text-sm font-semibold">
                  {roleData?.role === "imposter"
                    ? "Give a clue that sounds like you know the topic..."
                    : "Give a clue about the topic. Don't make it too obvious!"}
                </p>
                <div className="flex gap-2">
                  <Input
                    placeholder="Your clue..."
                    value={clueInput}
                    onChange={(e) => setClueInput(e.target.value)}
                    maxLength={80}
                    className="flex-1 h-11 bg-muted/40"
                    data-testid="input-clue"
                    onKeyDown={(e) => e.key === "Enter" && submitClue()}
                  />
                  <Button onClick={submitClue} disabled={!clueInput.trim()} className="h-11 px-4 box-glow" data-testid="button-submit-clue">
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="card-glass rounded-2xl p-4 flex items-center justify-center gap-2 border-secondary/30">
                <Check className="h-5 w-5 text-secondary" />
                <span className="font-semibold text-secondary">Clue submitted!</span>
              </div>
            )}

            {/* Other players */}
            <div className="card-glass rounded-2xl p-4 flex flex-col gap-2">
              <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-1">Players</p>
              {roomState.players.filter((p) => p.isConnected).map((player) => {
                const submitted = Boolean(roomState.clues[player.id]);
                return (
                  <div key={player.id} className={`flex items-center gap-3 p-2 rounded-lg ${player.id === playerId ? "bg-primary/10" : ""}`}
                    data-testid={`clue-player-${player.id}`}>
                    <div className={`w-2 h-2 rounded-full ${submitted ? "bg-secondary" : "bg-muted-foreground/40"}`} />
                    <span className="flex-1 text-sm font-medium">
                      {player.name} {player.id === playerId && <span className="text-xs text-muted-foreground">(you)</span>}
                    </span>
                    {submitted ? <Check className="h-4 w-4 text-secondary" /> : (
                      <motion.div animate={{ opacity: [0.4, 1, 0.4] }} transition={{ duration: 1.5, repeat: Infinity }}>
                        <Clock className="h-4 w-4 text-muted-foreground" />
                      </motion.div>
                    )}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* === DISCUSSION === */}
        {status === "discussion" && (
          <motion.div key="discussion" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col gap-5 flex-1">

            <TimerBar remaining={timerRemaining} total={roomState.discussionTimerSeconds} color="accent" />

            <div className="text-center">
              <h2 className="text-2xl font-black text-accent text-glow-accent">Who's the Imposter?</h2>
              <p className="text-sm text-muted-foreground mt-1">Discuss the clues and find the fake</p>
            </div>

            {/* Clues */}
            <div className="card-glass rounded-2xl p-4 flex flex-col gap-2">
              <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-1">Clues</p>
              {roomState.players.filter((p) => p.isConnected).map((player) => {
                const clue = roomState.clues[player.id];
                return (
                  <div key={player.id} className={`flex items-start gap-3 p-3 rounded-xl ${
                    player.id === playerId ? "bg-primary/10 border border-primary/20" : "bg-muted/30"
                  }`}
                    data-testid={`clue-item-${player.id}`}>
                    <div className="flex-1">
                      <span className="text-xs text-muted-foreground font-semibold">
                        {player.name} {player.id === playerId && "(you)"}
                      </span>
                      <p className="font-semibold text-sm mt-0.5">
                        {clue ?? <span className="text-muted-foreground italic">No clue submitted</span>}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="text-center text-sm text-muted-foreground py-2">
              Voting starts when the timer ends
            </div>
          </motion.div>
        )}

        {/* === VOTING === */}
        {status === "voting" && (
          <motion.div key="voting" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col gap-5 flex-1">

            <TimerBar remaining={timerRemaining} total={60} color="destructive" />

            <div className="text-center">
              <h2 className="text-2xl font-black text-primary text-glow">Vote!</h2>
              <p className="text-sm text-muted-foreground mt-1">
                {hasVoted ? "Vote cast. Waiting for others..." : "Tap to vote for who you think is the imposter"}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              {roomState.players.filter((p) => p.isConnected).map((player) => {
                const isSelf = player.id === playerId;
                const hasPlayerVoted = Boolean(roomState.votes[player.id]);
                return (
                  <button
                    key={player.id}
                    onClick={() => !hasVoted && !isSelf && submitVote(player.id)}
                    disabled={hasVoted || isSelf}
                    data-testid={`vote-button-${player.id}`}
                    className={`relative p-4 rounded-2xl border-2 text-left transition-all ${
                      isSelf ? "opacity-40 border-border/30 bg-muted/20 cursor-not-allowed" :
                      hasVoted ? "border-border/30 bg-muted/20 cursor-default" :
                      "border-primary/30 bg-primary/5 hover:border-primary hover:bg-primary/15 active:scale-95 cursor-pointer"
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <div className={`w-2 h-2 rounded-full ${player.isConnected ? "bg-secondary" : "bg-muted"}`} />
                      <span className="font-bold text-sm">{player.name}</span>
                    </div>
                    {hasPlayerVoted && (
                      <div className="flex items-center gap-1 mt-1">
                        <Check className="h-3 w-3 text-secondary" />
                        <span className="text-xs text-muted-foreground">Voted</span>
                      </div>
                    )}
                    {isSelf && <span className="text-xs text-muted-foreground">You</span>}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}

        {/* === REVEAL === */}
        {status === "reveal" && roomState.lastRoundResult && (
          <motion.div key="reveal" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-6 flex-1">

            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.3 }}
              className="text-center"
            >
              <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">The Imposter Was...</p>
              <div className={`text-5xl font-black tracking-tight ${
                roomState.lastRoundResult.wasImposterCaught ? "text-destructive text-glow" : "text-accent text-glow-accent"
              }`}>
                {roomState.lastRoundResult.imposterName}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className={`w-full rounded-2xl p-5 text-center border-2 ${
                roomState.lastRoundResult.wasImposterCaught
                  ? "bg-secondary/10 border-secondary/40"
                  : "bg-destructive/10 border-destructive/40"
              }`}
            >
              <div className="text-4xl mb-2">
                {roomState.lastRoundResult.wasImposterCaught
                  ? <Shield className="h-12 w-12 text-secondary mx-auto" />
                  : <Skull className="h-12 w-12 text-destructive mx-auto" />}
              </div>
              <p className={`text-2xl font-black ${
                roomState.lastRoundResult.wasImposterCaught ? "text-secondary" : "text-destructive"
              }`}>
                {roomState.lastRoundResult.wasImposterCaught ? "IMPOSTER CAUGHT!" : "IMPOSTER ESCAPES!"}
              </p>
              <p className="text-muted-foreground text-sm mt-1">
                Secret topic was: <strong className="text-foreground">{roomState.lastRoundResult.topic}</strong>
              </p>
            </motion.div>

            {/* Score changes */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.9 }}
              className="card-glass w-full rounded-2xl p-4"
            >
              <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-3">Score Changes</p>
              {roomState.players.map((player) => {
                const delta = roomState.lastRoundResult?.scoreDelta[player.id] ?? 0;
                return (
                  <div key={player.id} className="flex items-center justify-between py-1.5"
                    data-testid={`score-delta-${player.id}`}>
                    <div className="flex items-center gap-2">
                      {player.id === roomState.lastRoundResult?.imposterId && (
                        <Skull className="h-3.5 w-3.5 text-destructive" />
                      )}
                      <span className="font-medium text-sm">{player.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {delta > 0 && (
                        <span className="text-secondary font-bold text-sm">+{delta}</span>
                      )}
                      <span className="font-black">{player.score}</span>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          </motion.div>
        )}

        {/* === SCORES === */}
        {status === "scores" && (
          <motion.div key="scores" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="flex flex-col gap-5 flex-1">

            <div className="text-center">
              <h2 className="text-3xl font-black text-primary text-glow">
                {roomState.currentRound >= roomState.totalRounds ? "Game Over!" : "Scores"}
              </h2>
              <p className="text-sm text-muted-foreground mt-1">
                Round {roomState.currentRound} of {roomState.totalRounds}
              </p>
            </div>

            <div className="card-glass rounded-2xl p-4 flex flex-col gap-2">
              <p className="text-xs uppercase tracking-widest text-muted-foreground font-semibold mb-2 flex items-center gap-2">
                <Trophy className="h-4 w-4 text-yellow-400" /> Leaderboard
              </p>
              {[...roomState.players]
                .sort((a, b) => b.score - a.score)
                .map((player, idx) => (
                  <div key={player.id}
                    className={`flex items-center gap-3 p-3 rounded-xl ${
                      idx === 0 ? "bg-yellow-500/10 border border-yellow-500/30" :
                      player.id === playerId ? "bg-primary/10" : "bg-muted/30"
                    }`}
                    data-testid={`score-row-${player.id}`}>
                    <span className={`text-lg font-black w-6 text-center ${
                      idx === 0 ? "text-yellow-400" : "text-muted-foreground"
                    }`}>
                      {idx + 1}
                    </span>
                    <span className="flex-1 font-semibold">
                      {player.name} {player.id === playerId && <span className="text-xs text-muted-foreground">(you)</span>}
                    </span>
                    <span className="font-black text-lg">{player.score}</span>
                  </div>
                ))}
            </div>

            {isHost && (
              <div className="flex flex-col gap-2">
                {roomState.currentRound < roomState.totalRounds && (
                  <Button className="h-12 font-bold box-glow" onClick={emitNextRound} data-testid="button-next-round">
                    Next Round <ChevronRight className="ml-1 h-4 w-4" />
                  </Button>
                )}
                <Button variant="outline" className="h-12 font-bold border-muted" onClick={emitResetLobby}
                  data-testid="button-reset-lobby">
                  <RotateCcw className="mr-2 h-4 w-4" /> Play Again
                </Button>
                <Button variant="ghost" size="sm" onClick={emitEndGame} className="text-muted-foreground"
                  data-testid="button-end-game">
                  End Game & Return Home
                </Button>
              </div>
            )}
            {!isHost && (
              <p className="text-center text-sm text-muted-foreground">Waiting for the host...</p>
            )}
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}

function TimerBar({ remaining, total, color }: { remaining: number; total: number; color: "primary" | "accent" | "destructive" }) {
  const pct = total > 0 ? (remaining / total) * 100 : 0;
  const colorMap = {
    primary: "bg-primary",
    accent: "bg-accent",
    destructive: "bg-destructive",
  };
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1 bg-muted/50 rounded-full h-2 overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${colorMap[color]}`}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.5 }}
        />
      </div>
      <span className={`text-sm font-bold tabular-nums ${
        remaining <= 10 ? "text-destructive" : "text-muted-foreground"
      }`}>
        {remaining}s
      </span>
    </div>
  );
}

function Zap({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M13 2L4.09 12.26a1 1 0 0 0 .91 1.74H11l-2 8 8.91-10.26a1 1 0 0 0-.91-1.74H11l2-8z" />
    </svg>
  );
}
