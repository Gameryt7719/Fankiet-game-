import { Router, type IRouter } from "express";
import { topicPacks } from "../lib/topics";

const router: IRouter = Router();

router.get("/topics", async (_req, res): Promise<void> => {
  const categories = topicPacks.map((p) => ({
    id: p.id,
    name: p.name,
    description: p.description,
    topicCount: p.topics.length,
    isAdult: p.isAdult,
  }));
  res.json(categories);
});

export default router;
