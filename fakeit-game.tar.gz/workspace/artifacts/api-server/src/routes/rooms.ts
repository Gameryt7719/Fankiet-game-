import { Router, type IRouter } from "express";
import { randomUUID } from "crypto";
import {
  CreateRoomBody,
  JoinRoomBody,
  GetRoomParams,
  JoinRoomParams,
  GetRoomScoresParams,
} from "@workspace/api-zod";
import {
  createRoom as createGameRoom,
  getRoom,
  joinRoom as joinGameRoom,
  roomToPublicState,
} from "../lib/game-state";
import { db, gameScoresTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router: IRouter = Router();

router.post("/rooms", async (req, res): Promise<void> => {
  const parsed = CreateRoomBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { hostName, category, totalRounds, maxPlayers, clueTimerSeconds, discussionTimerSeconds } = parsed.data;
  const hostId = randomUUID();

  const room = createGameRoom(hostId, hostName, {
    category: category ?? "general",
    totalRounds: totalRounds ?? 3,
    maxPlayers: maxPlayers ?? 8,
    clueTimerSeconds: clueTimerSeconds ?? 60,
    discussionTimerSeconds: discussionTimerSeconds ?? 90,
  });

  req.log.info({ code: room.code, hostName }, "Room created");

  res.status(201).json({
    ...roomToPublicState(room),
    hostId, // Return hostId so client can store it
  });
});

router.get("/rooms/:code", async (req, res): Promise<void> => {
  const params = GetRoomParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const room = getRoom(params.data.code);
  if (!room) {
    res.status(404).json({ error: "Room not found" });
    return;
  }

  res.json(roomToPublicState(room));
});

router.post("/rooms/:code/join", async (req, res): Promise<void> => {
  const params = JoinRoomParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = JoinRoomBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const playerId = randomUUID();
  const result = joinGameRoom(params.data.code, playerId, body.data.playerName);

  if (!result.success) {
    const room = getRoom(params.data.code);
    if (!room) {
      res.status(404).json({ error: result.error });
      return;
    }
    res.status(400).json({ error: result.error });
    return;
  }

  const room = getRoom(params.data.code)!;
  req.log.info({ code: params.data.code, playerName: body.data.playerName }, "Player joined room");

  res.json({
    room: roomToPublicState(room),
    playerId,
  });
});

router.get("/rooms/:code/scores", async (req, res): Promise<void> => {
  const params = GetRoomScoresParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  // First try in-memory state
  const room = getRoom(params.data.code);
  if (room) {
    const scores = [...room.players.values()].map((p) => ({
      playerId: p.id,
      name: p.name,
      score: p.score,
      roundsWon: p.roundsWon,
    }));
    res.json(scores);
    return;
  }

  // Fall back to DB
  const dbScores = await db
    .select()
    .from(gameScoresTable)
    .where(eq(gameScoresTable.roomCode, params.data.code.toUpperCase()));

  if (dbScores.length === 0) {
    res.status(404).json({ error: "Room not found" });
    return;
  }

  res.json(
    dbScores.map((s) => ({
      playerId: s.playerId,
      name: s.playerName,
      score: s.score,
      roundsWon: s.roundsWon,
    }))
  );
});

export default router;
