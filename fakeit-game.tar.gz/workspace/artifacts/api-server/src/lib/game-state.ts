import { Server as SocketIOServer, Socket } from "socket.io";
import { getRandomTopic } from "./topics";
import { logger } from "./logger";
import { db, roomsTable, gameScoresTable } from "@workspace/db";
import { randomUUID } from "crypto";

export type GameStatus =
  | "lobby"
  | "role_reveal"
  | "clue_phase"
  | "discussion"
  | "voting"
  | "reveal"
  | "scores";

export interface Player {
  id: string;
  name: string;
  isHost: boolean;
  score: number;
  roundsWon: number;
  isConnected: boolean;
  socketId: string | null;
}

export interface RoundResult {
  imposterId: string;
  imposterName: string;
  topic: string;
  wasImposterCaught: boolean;
  votes: Record<string, string>; // voterId -> targetId
  clues: Record<string, string>; // playerId -> clue
  scoreDelta: Record<string, number>; // playerId -> points earned
}

interface GameRoom {
  code: string;
  players: Map<string, Player>;
  status: GameStatus;
  currentRound: number;
  totalRounds: number;
  category: string;
  maxPlayers: number;
  clueTimerSeconds: number;
  discussionTimerSeconds: number;
  topic: string | null;
  imposterId: string | null;
  clues: Map<string, string>;
  votes: Map<string, string>;
  clueTimer: ReturnType<typeof setTimeout> | null;
  discussionTimer: ReturnType<typeof setTimeout> | null;
  timerEndAt: number | null;
  lastRoundResult: RoundResult | null;
}

const rooms = new Map<string, GameRoom>();

function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function createRoom(
  hostId: string,
  hostName: string,
  options: {
    category?: string;
    totalRounds?: number;
    maxPlayers?: number;
    clueTimerSeconds?: number;
    discussionTimerSeconds?: number;
  } = {}
): GameRoom {
  let code = generateRoomCode();
  while (rooms.has(code)) {
    code = generateRoomCode();
  }

  const host: Player = {
    id: hostId,
    name: hostName,
    isHost: true,
    score: 0,
    roundsWon: 0,
    isConnected: false,
    socketId: null,
  };

  const room: GameRoom = {
    code,
    players: new Map([[hostId, host]]),
    status: "lobby",
    currentRound: 0,
    totalRounds: options.totalRounds ?? 3,
    category: options.category ?? "general",
    maxPlayers: options.maxPlayers ?? 8,
    clueTimerSeconds: options.clueTimerSeconds ?? 60,
    discussionTimerSeconds: options.discussionTimerSeconds ?? 90,
    topic: null,
    imposterId: null,
    clues: new Map(),
    votes: new Map(),
    clueTimer: null,
    discussionTimer: null,
    timerEndAt: null,
    lastRoundResult: null,
  };

  rooms.set(code, room);

  db.insert(roomsTable)
    .values({
      code,
      category: room.category,
      totalRounds: room.totalRounds,
    })
    .catch((err) => logger.error({ err }, "Failed to persist room"));

  return room;
}

export function getRoom(code: string): GameRoom | undefined {
  return rooms.get(code.toUpperCase());
}

export function joinRoom(
  code: string,
  playerId: string,
  playerName: string
): { success: boolean; error?: string; player?: Player } {
  const room = rooms.get(code.toUpperCase());
  if (!room) return { success: false, error: "Room not found" };
  if (room.status !== "lobby") return { success: false, error: "Game already in progress" };
  if (room.players.size >= room.maxPlayers) return { success: false, error: "Room is full" };

  const existing = [...room.players.values()].find(
    (p) => p.name.toLowerCase() === playerName.toLowerCase()
  );
  if (existing) return { success: false, error: "Name already taken in this room" };

  const player: Player = {
    id: playerId,
    name: playerName,
    isHost: false,
    score: 0,
    roundsWon: 0,
    isConnected: false,
    socketId: null,
  };

  room.players.set(playerId, player);
  return { success: true, player };
}

export function roomToPublicState(room: GameRoom) {
  return {
    code: room.code,
    players: [...room.players.values()].map((p) => ({
      id: p.id,
      name: p.name,
      isHost: p.isHost,
      score: p.score,
      isConnected: p.isConnected,
    })),
    status: room.status,
    currentRound: room.currentRound,
    totalRounds: room.totalRounds,
    category: room.category,
    maxPlayers: room.maxPlayers,
    clueTimerSeconds: room.clueTimerSeconds,
    discussionTimerSeconds: room.discussionTimerSeconds,
    timerEndAt: room.timerEndAt,
    clues: Object.fromEntries(room.clues),
    votes: room.status === "reveal" || room.status === "scores" ? Object.fromEntries(room.votes) : {},
    lastRoundResult: room.lastRoundResult,
  };
}

function clearTimers(room: GameRoom) {
  if (room.clueTimer) {
    clearTimeout(room.clueTimer);
    room.clueTimer = null;
  }
  if (room.discussionTimer) {
    clearTimeout(room.discussionTimer);
    room.discussionTimer = null;
  }
  room.timerEndAt = null;
}

export function setupSocketIO(io: SocketIOServer) {
  io.on("connection", (socket: Socket) => {
    const { roomCode, playerId } = socket.handshake.auth as {
      roomCode: string;
      playerId: string;
    };

    if (!roomCode || !playerId) {
      socket.disconnect();
      return;
    }

    const room = rooms.get(roomCode.toUpperCase());
    if (!room) {
      socket.emit("error", { message: "Room not found" });
      socket.disconnect();
      return;
    }

    const player = room.players.get(playerId);
    if (!player) {
      socket.emit("error", { message: "Player not found in room" });
      socket.disconnect();
      return;
    }

    // Mark player as connected
    player.isConnected = true;
    player.socketId = socket.id;
    socket.join(roomCode.toUpperCase());

    logger.info({ roomCode, playerId, playerName: player.name }, "Player connected");

    // Send current room state to the connecting player
    socket.emit("room_state", roomToPublicState(room));
    // Notify others
    socket.to(roomCode.toUpperCase()).emit("room_state", roomToPublicState(room));

    // --- Game events ---

    socket.on("start_game", () => {
      if (room.status !== "lobby") return;
      if (player.id !== [...room.players.values()].find((p) => p.isHost)?.id) return;
      if (room.players.size < 3) {
        socket.emit("error", { message: "Need at least 3 players to start" });
        return;
      }
      startRound(io, room);
    });

    socket.on("submit_clue", ({ clue }: { clue: string }) => {
      if (room.status !== "clue_phase") return;
      if (room.clues.has(playerId)) return;
      if (typeof clue !== "string" || clue.trim().length === 0) return;

      room.clues.set(playerId, clue.trim().substring(0, 100));
      io.to(roomCode.toUpperCase()).emit("room_state", roomToPublicState(room));

      // If all players have submitted clues, advance
      const connectedPlayers = [...room.players.values()].filter((p) => p.isConnected);
      if (room.clues.size >= connectedPlayers.length) {
        clearTimers(room);
        startDiscussion(io, room);
      }
    });

    socket.on("submit_vote", ({ targetId }: { targetId: string }) => {
      if (room.status !== "voting") return;
      if (room.votes.has(playerId)) return;
      if (!room.players.has(targetId)) return;
      if (targetId === playerId) return;

      room.votes.set(playerId, targetId);
      io.to(roomCode.toUpperCase()).emit("room_state", roomToPublicState(room));

      // If all non-imposter players have voted, advance
      const connectedPlayers = [...room.players.values()].filter((p) => p.isConnected);
      if (room.votes.size >= connectedPlayers.length - 1 || room.votes.size >= connectedPlayers.length) {
        clearTimers(room);
        revealResults(io, room);
      }
    });

    socket.on("next_round", () => {
      if (room.status !== "scores") return;
      if (player.id !== [...room.players.values()].find((p) => p.isHost)?.id) return;
      if (room.currentRound >= room.totalRounds) {
        endGame(io, room);
        return;
      }
      startRound(io, room);
    });

    socket.on("end_game", () => {
      if (!["scores", "reveal", "lobby"].includes(room.status)) return;
      if (player.id !== [...room.players.values()].find((p) => p.isHost)?.id) return;
      endGame(io, room);
    });

    socket.on("reset_to_lobby", () => {
      if (player.id !== [...room.players.values()].find((p) => p.isHost)?.id) return;
      clearTimers(room);
      room.status = "lobby";
      room.currentRound = 0;
      room.topic = null;
      room.imposterId = null;
      room.clues.clear();
      room.votes.clear();
      room.lastRoundResult = null;
      for (const p of room.players.values()) {
        p.score = 0;
        p.roundsWon = 0;
      }
      io.to(roomCode.toUpperCase()).emit("room_state", roomToPublicState(room));
    });

    socket.on("disconnect", () => {
      player.isConnected = false;
      player.socketId = null;
      logger.info({ roomCode, playerId }, "Player disconnected");
      io.to(roomCode.toUpperCase()).emit("room_state", roomToPublicState(room));

      // If all players disconnected, schedule room cleanup
      const anyConnected = [...room.players.values()].some((p) => p.isConnected);
      if (!anyConnected) {
        setTimeout(() => {
          const stillEmpty = [...room.players.values()].every((p) => !p.isConnected);
          if (stillEmpty) {
            clearTimers(room);
            rooms.delete(roomCode.toUpperCase());
            logger.info({ roomCode }, "Room cleaned up after all players disconnected");
          }
        }, 5 * 60 * 1000); // 5 minutes
      }
    });
  });
}

function startRound(io: SocketIOServer, room: GameRoom) {
  room.currentRound += 1;
  room.topic = getRandomTopic(room.category);
  room.clues.clear();
  room.votes.clear();
  room.lastRoundResult = null;

  // Pick a random imposter from connected players
  const connectedPlayers = [...room.players.values()].filter((p) => p.isConnected);
  const imposter = connectedPlayers[Math.floor(Math.random() * connectedPlayers.length)];
  room.imposterId = imposter.id;

  room.status = "role_reveal";

  // Send private role info to each player
  for (const player of connectedPlayers) {
    const isImposter = player.id === room.imposterId;
    io.to(player.socketId!).emit("role_assigned", {
      role: isImposter ? "imposter" : "player",
      topic: isImposter ? null : room.topic,
    });
  }

  io.to(room.code).emit("room_state", roomToPublicState(room));

  // Auto-advance to clue phase after 8 seconds
  setTimeout(() => {
    if (room.status === "role_reveal") {
      startCluePhase(io, room);
    }
  }, 8000);
}

function startCluePhase(io: SocketIOServer, room: GameRoom) {
  room.status = "clue_phase";
  room.timerEndAt = Date.now() + room.clueTimerSeconds * 1000;

  io.to(room.code).emit("room_state", roomToPublicState(room));

  room.clueTimer = setTimeout(() => {
    if (room.status === "clue_phase") {
      startDiscussion(io, room);
    }
  }, room.clueTimerSeconds * 1000);
}

function startDiscussion(io: SocketIOServer, room: GameRoom) {
  room.status = "discussion";
  room.timerEndAt = Date.now() + room.discussionTimerSeconds * 1000;

  io.to(room.code).emit("room_state", roomToPublicState(room));

  room.discussionTimer = setTimeout(() => {
    if (room.status === "discussion") {
      startVoting(io, room);
    }
  }, room.discussionTimerSeconds * 1000);
}

function startVoting(io: SocketIOServer, room: GameRoom) {
  room.status = "voting";
  room.timerEndAt = Date.now() + 60000; // 60 seconds to vote

  io.to(room.code).emit("room_state", roomToPublicState(room));

  room.clueTimer = setTimeout(() => {
    if (room.status === "voting") {
      revealResults(io, room);
    }
  }, 60000);
}

function revealResults(io: SocketIOServer, room: GameRoom) {
  room.status = "reveal";
  room.timerEndAt = null;

  const imposterId = room.imposterId!;
  const imposter = room.players.get(imposterId)!;

  // Tally votes
  const voteCounts = new Map<string, number>();
  for (const targetId of room.votes.values()) {
    voteCounts.set(targetId, (voteCounts.get(targetId) ?? 0) + 1);
  }

  // Find most voted player
  let maxVotes = 0;
  let mostVotedId: string | null = null;
  for (const [targetId, count] of voteCounts) {
    if (count > maxVotes) {
      maxVotes = count;
      mostVotedId = targetId;
    }
  }

  const wasImposterCaught = mostVotedId === imposterId;
  const scoreDelta: Record<string, number> = {};

  for (const player of room.players.values()) {
    scoreDelta[player.id] = 0;
  }

  if (wasImposterCaught) {
    // Players who voted correctly get 2 points each
    for (const [voterId, targetId] of room.votes) {
      if (targetId === imposterId) {
        const voter = room.players.get(voterId);
        if (voter) {
          voter.score += 2;
          voter.roundsWon += 1;
          scoreDelta[voterId] = (scoreDelta[voterId] ?? 0) + 2;
        }
      }
    }
  } else {
    // Imposter wins - gets 3 points
    imposter.score += 3;
    imposter.roundsWon += 1;
    scoreDelta[imposterId] = 3;

    // Players who voted for imposter still get 1 point for being suspicious
    for (const [voterId, targetId] of room.votes) {
      if (targetId === imposterId) {
        const voter = room.players.get(voterId);
        if (voter) {
          voter.score += 1;
          scoreDelta[voterId] = (scoreDelta[voterId] ?? 0) + 1;
        }
      }
    }
  }

  room.lastRoundResult = {
    imposterId,
    imposterName: imposter.name,
    topic: room.topic!,
    wasImposterCaught,
    votes: Object.fromEntries(room.votes),
    clues: Object.fromEntries(room.clues),
    scoreDelta,
  };

  io.to(room.code).emit("room_state", roomToPublicState(room));

  // Auto-advance to scores after 6 seconds
  setTimeout(() => {
    if (room.status === "reveal") {
      room.status = "scores";
      io.to(room.code).emit("room_state", roomToPublicState(room));
    }
  }, 6000);

  // Persist scores
  persistScores(room).catch((err) =>
    logger.error({ err }, "Failed to persist scores")
  );
}

function endGame(io: SocketIOServer, room: GameRoom) {
  clearTimers(room);
  room.status = "scores";
  room.currentRound = room.totalRounds; // Force to end
  io.to(room.code).emit("room_state", roomToPublicState(room));
}

async function persistScores(room: GameRoom) {
  const values = [...room.players.values()].map((p) => ({
    id: randomUUID(),
    roomCode: room.code,
    playerName: p.name,
    playerId: p.id,
    score: p.score,
    roundsWon: p.roundsWon,
  }));

  if (values.length === 0) return;

  await db.insert(gameScoresTable).values(values).onConflictDoNothing();
}
