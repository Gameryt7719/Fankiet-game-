# Fakeit — AI Build Session Log
**Tool:** Replit Agent (Claude-based)  
**Date:** May 23, 2026  
**Project:** Fakeit — Real-time Multiplayer Imposter Party Game

---

## User Request

> Reference app: Imposter Game — Fakeit — a viral social party game with 109M+ views.
>
> What to build: A real-time multiplayer party game where one player is the "imposter" who doesn't know the secret topic. Other players give clues, and everyone votes on who they think the imposter is. Runs locally (same room) or over the internet.
>
> Key features:
> - Room creation with shareable code (4-8 players)
> - Role assignment — imposter vs. players
> - Timer-based clue/discussion phase
> - Voting screen with animated reveal
> - Score tracking across rounds
> - Topic category packs (general, adult, family)
>
> Reference apps: Imposter Game, TOZ, Party Lab, DAFUQ
> Scoring focus: Real-time multiplayer reliability, game flow UX, and fun factor.

---

## Architecture Decisions Made

1. **In-memory game state** — All real-time game state lives in a `Map<string, GameRoom>` on the server rather than round-tripping through the database on every socket event. Only final scores are persisted to PostgreSQL.

2. **Socket.io for real-time** — Used Socket.io over raw WebSockets for built-in room support, reconnection handling, and event acknowledgements. Configured at path `/socket.io` on the same Express server as the REST API.

3. **Proxy path routing** — The shared reverse proxy routes by path prefix. Added `/socket.io` alongside `/api` in the api-server `artifact.toml` so both reach port 8080.

4. **Private role delivery** — Role/topic information is sent via `socket.to(player.socketId).emit('role_assigned', ...)` — targeted to a single socket, never broadcast to the room — so only the correct player sees their role.

5. **Single Room page** — All 7 game states (lobby, role_reveal, clue_phase, discussion, voting, reveal, scores) live in one `/room/:code` React page. State is driven entirely by `roomState.status` from socket events.

6. **OpenAPI-first** — Defined the REST contract in `lib/api-spec/openapi.yaml` first, ran codegen to generate React Query hooks and Zod validators, then built both frontend and backend against the generated types.

---

## Build Steps

### Step 1: OpenAPI Spec
Designed endpoints for:
- `POST /rooms` — create room
- `GET /rooms/{code}` — get room state
- `POST /rooms/{code}/join` — join room
- `GET /rooms/{code}/scores` — get scores
- `GET /topics` — list topic categories

### Step 2: Codegen
```bash
pnpm --filter @workspace/api-spec run codegen
```
Generated React Query hooks and Zod schemas from the spec.

### Step 3: Database Schema
Created `rooms` and `game_scores` tables in `lib/db/src/schema/rooms.ts`.
```bash
pnpm --filter @workspace/db run push
```

### Step 4: Backend — Game State Engine
Built `artifacts/api-server/src/lib/game-state.ts`:
- In-memory `Map<string, GameRoom>` store
- `createRoom()`, `getRoom()`, `joinRoom()` functions
- `setupSocketIO()` wiring all socket events
- Full game flow: lobby → role_reveal → clue_phase → discussion → voting → reveal → scores
- Scoring: +2 per correct voter, +3 for imposter escape
- Auto-timer transitions (role reveal: 8s, then clue phase, discussion, voting)

### Step 5: Topic Packs
Created `artifacts/api-server/src/lib/topics.ts` with 4 category packs:
- **General**: 88 topics (everyday places/events)
- **Family Fun**: 53 topics (all ages)
- **Pop Culture**: 41 topics (movies, music, internet)
- **Adults Only**: 44 topics (mature content)

### Step 6: Express Routes
- `artifacts/api-server/src/routes/rooms.ts` — REST room management
- `artifacts/api-server/src/routes/topics.ts` — topic categories
- Updated `artifacts/api-server/src/index.ts` to use `http.createServer()` for Socket.io attachment

### Step 7: Frontend
Updated CSS theme to **Neon Arcade Dark**:
- Background: near-black (240 15% 4%)
- Primary: Electric Pink (322 100% 58%)
- Secondary: Neon Cyan (185 100% 48%)
- Accent: Electric Purple (275 100% 62%)
- Custom utilities: `.text-glow`, `.box-glow`, `.card-glass`

Built pages:
- `src/pages/Home.tsx` — animated home with create/join flows, category selector, round picker
- `src/pages/Room.tsx` — full game room with all 7 state views, real-time timer bars, role reveal card flip, voting grid, animated score reveal
- `src/lib/socket.tsx` — Socket.io context provider (connect/disconnect, room_state listener, role_assigned handler)

### Step 8: Artifact Config
Updated `api-server/.replit-artifact/artifact.toml` to add `/socket.io` to the `paths` array alongside `/api`.

---

## Socket.io Event Reference

### Client → Server
| Event | Payload | Description |
|-------|---------|-------------|
| `start_game` | — | Host starts the game |
| `submit_clue` | `{ clue: string }` | Player submits a clue |
| `submit_vote` | `{ targetId: string }` | Player votes for imposter |
| `next_round` | — | Host advances to next round |
| `end_game` | — | Host ends game early |
| `reset_to_lobby` | — | Host resets to lobby (new game) |

### Server → Client
| Event | Payload | Description |
|-------|---------|-------------|
| `room_state` | Full `RoomState` object | Broadcast on any state change |
| `role_assigned` | `{ role, topic }` | Private — sent only to the player |
| `error` | `{ message: string }` | Error notification |

---

## Files Created / Modified

### New Files
- `lib/db/src/schema/rooms.ts`
- `artifacts/api-server/src/lib/game-state.ts`
- `artifacts/api-server/src/lib/topics.ts`
- `artifacts/api-server/src/routes/rooms.ts`
- `artifacts/api-server/src/routes/topics.ts`
- `artifacts/3d-game/src/pages/Home.tsx`
- `artifacts/3d-game/src/pages/Room.tsx`
- `artifacts/3d-game/src/lib/socket.tsx`

### Modified Files
- `lib/api-spec/openapi.yaml` — added game endpoints
- `lib/db/src/schema/index.ts` — re-export rooms schema
- `artifacts/api-server/src/index.ts` — http.createServer + Socket.io setup
- `artifacts/api-server/src/routes/index.ts` — added rooms + topics routers
- `artifacts/api-server/.replit-artifact/artifact.toml` — added `/socket.io` path
- `artifacts/3d-game/src/App.tsx` — added SocketProvider + Room route
- `artifacts/3d-game/src/index.css` — complete neon arcade theme
- `replit.md` — project documentation
