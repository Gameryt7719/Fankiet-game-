# Reflection — Fakeit: The Imposter Party Game

## What I Built

A fully real-time multiplayer imposter party game inspired by the viral Fakeit/TOZ format. Players join a shared room via a 6-character code, receive secret roles, give clues about a hidden topic, debate who the imposter is, and vote. Scores persist across rounds. Runs over the internet via WebSockets — no same-network requirement.

**Stack:** React + Vite, Express 5, Socket.io, PostgreSQL + Drizzle ORM, TypeScript, pnpm monorepo, Tailwind CSS (custom neon arcade theme).

---

## What Was Easy

**Game flow logic** — The state machine for a party game is actually straightforward once you commit to an in-memory model. Keeping all real-time state in a `Map<string, GameRoom>` on the server (and only writing final scores to the DB) made the flow clean: every socket event mutates state and re-broadcasts the full `room_state` to all clients. No complex sync issues, no stale data problems.

**TypeScript across the stack** — Using a pnpm monorepo with a shared `lib/api-spec` package (OpenAPI → Orval codegen) meant the frontend and backend stayed in sync automatically. Writing the OpenAPI contract first and generating React Query hooks + Zod validators from it removed a whole category of "did I forget to update the frontend types?" bugs.

**The UI theme** — Dark neon arcade visuals work beautifully for a party game. Tailwind's utility classes plus a handful of custom CSS variables (`--color-primary`, `--color-secondary`) made it easy to stay consistent across all game states with glows, gradients, and animated elements.

---

## What Was Difficult

**Socket.io through the proxy** — The Replit shared reverse proxy routes traffic by path prefix using mTLS. Socket.io uses a long-lived WebSocket connection on a specific path (`/socket.io`). I had to explicitly add `/socket.io` to the api-server's `artifact.toml` paths array — without it, Socket.io upgrade requests were silently dropped. The symptom was confusing: HTTP requests worked, but sockets never connected.

**Private role delivery** — Sending a secret topic only to non-imposter players (without ever broadcasting it to the room) required using `socket.to(player.socketId).emit(...)` rather than the room-level broadcast. Getting this right meant carefully tracking socket IDs when players reconnect, since a reconnect changes the socket ID and the old targeted messages would go nowhere.

**Timer synchronization** — Running timers server-side (to prevent cheating) but keeping the UI timer bars smooth client-side required storing `timerEndAt` as an absolute timestamp in the room state, broadcasting it with each state update, and having the client calculate remaining time from `timerEndAt - Date.now()`. This way even late-joining clients get the correct remaining time instantly.

**Reconnection handling** — When a player closes and reopens their tab, they need to re-join the socket room and get the current game state pushed to them. This required checking for an existing `playerId` in `sessionStorage`, sending it as socket auth on connect, and the server restoring the player's socket ID in the `GameRoom`.

---

## What I Learned

1. **Contract-first API design pays dividends fast.** Writing the OpenAPI spec before touching the backend or frontend felt like extra work upfront, but it meant I could build both sides in parallel without merge conflicts or mismatched assumptions. The codegen'd hooks just worked.

2. **In-memory state + event sourcing is the right model for party games.** The DB round-trip penalty would have made the game feel sluggish. Keeping everything in memory and only persisting after-round scores was the correct architectural call. The trade-off (state lost on server restart mid-game) is acceptable for a party game.

3. **Absolute timestamps > relative countdowns for sync.** Broadcasting a `timerEndAt: number` is far more robust than broadcasting "60 seconds remaining." Relative countdowns drift as network latency varies; absolute timestamps mean every client computes the same remaining time from their local clock.

4. **pnpm workspaces + TypeScript project references scale well.** Even across a non-trivial monorepo (shared DB lib, shared API spec, separate frontend and backend artifacts), the setup was clean. The `pnpm --filter` commands made targeting specific packages intuitive.

---

## If I Had More Time

- **Spectator mode** — Let people watch a live game without participating
- **Custom topics** — Let the host type in their own topic instead of using the packs
- **Mobile-first optimizations** — The game is naturally played on phones; better touch targets, PWA manifest, fullscreen API
- **Room persistence** — Store in-progress room state to DB every N seconds so server restarts don't wipe active games
- **Animated role reveal** — Card flip animation with the phone-shield mechanic needs more polish to match the physical game feel
- **Sound effects** — Subtle audio cues for timers running out, votes being cast, the imposter being revealed

---

## Stack Summary

| Layer | Choice | Why |
|-------|--------|-----|
| Frontend | React + Vite | Fast HMR, great TypeScript support |
| Styling | Tailwind + custom CSS vars | Utility classes + themeable design tokens |
| Real-time | Socket.io | Room management, reconnects, event acks built in |
| API | Express 5 | Familiar, async-native in v5 |
| ORM | Drizzle | Lightweight, type-safe, great with PostgreSQL |
| Validation | Zod | Shared schemas across client and server |
| Codegen | Orval | OpenAPI → React Query hooks + Zod |
| Monorepo | pnpm workspaces | Fast installs, strict isolation |
