# FAKEIT — The Imposter Party Game

> *One player knows nothing. Everyone else knows everything. Can you spot the imposter?*

A real-time multiplayer party game inspired by the viral Fakeit/TOZ format with 109M+ views. Built for 3–8 players, playable in the same room or over the internet.

## Live Demo

**[Play now on Replit →](https://fakeit-game.replit.app)**

---

## How It Works

1. **Host creates a room** — picks a topic category and number of rounds, gets a 6-character shareable code
2. **Players join** — on their own phones via the room code
3. **Roles are assigned secretly** — one random player becomes the Imposter and sees `???` instead of the topic
4. **Clue phase** — everyone gives a one-word clue about the topic. The imposter must bluff
5. **Discussion** — players debate who they think the imposter is
6. **Vote** — everyone votes. Scores are awarded and the imposter is revealed
7. **Repeat** across rounds, track scores on the leaderboard

---

## Screenshots

| Home | Role Cards |
|------|------------|
| ![Home](screenshots/01-home.jpg) | ![Roles](screenshots/04-role-cards.jpg) |

---

## Features

- Real-time multiplayer via WebSockets — same room or across the internet
- 4 topic category packs: **General** (88), **Family Fun** (53), **Pop Culture** (41), **Adults Only** (44)
- Shield-your-phone role reveal mechanic — tap to show/hide your topic
- Timer-based clue phase, discussion, and voting
- Animated reveal — find out if the imposter escaped
- Score tracking across rounds with a final leaderboard
- Configurable rounds (1–10), clue timer, and discussion timer
- Real-time player connection status

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite + Tailwind CSS |
| Real-time | Socket.io |
| Backend | Express 5 (Node.js) |
| Database | PostgreSQL + Drizzle ORM |
| Validation | Zod |
| API contract | OpenAPI + Orval codegen |
| Monorepo | pnpm workspaces |
| Language | TypeScript throughout |

---

## Run Locally

**Prerequisites:** Node.js 20+, pnpm, PostgreSQL

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/fakeit-game.git
cd fakeit-game

# Install dependencies
pnpm install

# Set up environment
echo "DATABASE_URL=postgresql://localhost/fakeit" > .env

# Push database schema
pnpm --filter @workspace/db run push

# Start the API server (port 8080)
pnpm --filter @workspace/api-server run dev

# In a second terminal, start the frontend (port 24982)
pnpm --filter @workspace/3d-game run dev
```

Open [http://localhost:24982](http://localhost:24982) to play.

---

## Project Structure

```
artifacts/
  api-server/      # Express + Socket.io backend
  3d-game/         # React + Vite frontend
lib/
  api-spec/        # OpenAPI contract (source of truth)
  db/              # Drizzle schema + migrations
  api-client-react/ # Generated React Query hooks
  api-zod/         # Generated Zod validators
ai-logs/           # AI conversation logs (build session)
```

---

## AI Logs

Full build conversation and architectural decisions documented in [`/ai-logs`](./ai-logs/).

---

## Built With

Built using [Replit Agent](https://replit.com) for the [Replit AI Hackathon].
