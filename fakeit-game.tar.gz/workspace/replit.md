# Fakeit — The Imposter Party Game

A real-time multiplayer party game inspired by the viral Imposter/Fakeit format. One player is the imposter who doesn't know the secret topic. Others give clues, everyone discusses, then votes. Score tracks across rounds.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/3d-game run dev` — run the frontend (port 24982)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind (neon arcade dark theme)
- API: Express 5 + Socket.io for real-time game events
- DB: PostgreSQL + Drizzle ORM (persistent score tracking)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Animations: Framer Motion
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — API contract (source of truth)
- `lib/db/src/schema/rooms.ts` — DB schema for rooms and scores
- `artifacts/api-server/src/lib/game-state.ts` — in-memory game state + socket.io event handlers
- `artifacts/api-server/src/lib/topics.ts` — topic packs (general, family, pop culture, adult)
- `artifacts/api-server/src/routes/rooms.ts` — REST routes for room management
- `artifacts/3d-game/src/pages/Home.tsx` — home page (create/join room)
- `artifacts/3d-game/src/pages/Room.tsx` — game room page (all 7 game states)
- `artifacts/3d-game/src/lib/socket.tsx` — socket.io context + provider

## Architecture decisions

- **In-memory game state**: All real-time game state lives in a `Map<string, GameRoom>` on the server. DB only persists final scores. This avoids DB round-trips on every event and keeps latency minimal.
- **Socket.io path**: Socket.io runs at `/socket.io` on the same Express server (port 8080). The proxy artifact.toml lists both `/api` and `/socket.io` paths so both reach the same service.
- **Single room page**: All 7 game states (lobby, role_reveal, clue_phase, discussion, voting, reveal, scores) are handled in one `/room/:code` page via conditional rendering on `roomState.status`.
- **Private role delivery**: Role/topic info is sent via targeted `socket.to(player.socketId).emit('role_assigned', ...)` — never broadcast to the room.
- **Score persistence**: Scores are written to `game_scores` table after each round reveal so leaderboards survive server restarts.

## Product

- Room creation with 6-character shareable code (3-8 players)
- 4 topic packs: General (88 topics), Family Fun (53), Pop Culture (41), Adults Only (44)
- Timer-based clue phase → discussion → voting → animated reveal
- Per-round score system: +2 per correct vote, +3 for imposter escape
- Configurable rounds (1-10), clue timer, discussion timer
- Real-time player connection status
- Role reveal with shield-your-phone mechanic

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After OpenAPI spec changes, always re-run codegen before writing routes: `pnpm --filter @workspace/api-spec run codegen`
- Socket.io must have `/socket.io` listed in the api-server artifact.toml paths array or connections will be silently dropped by the proxy
- Rooms auto-cleanup 5 minutes after all players disconnect
- Room codes are case-insensitive (stored and compared as uppercase)

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
